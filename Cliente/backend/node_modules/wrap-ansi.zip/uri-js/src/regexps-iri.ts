import { URIRegExps } from "./uri";
import { buildExps } from "./regexps-uri";

export default buildExps(true);
